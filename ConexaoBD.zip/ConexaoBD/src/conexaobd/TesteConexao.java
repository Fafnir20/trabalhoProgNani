/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexaobd;

import java.sql.DriverManager;
import java.sql.*;


/**
 *
 * @author joseinacio
 */
public class TesteConexao {
    private Connection conexao;
    private PreparedStatement ps;
    private Statement statement;
    private ResultSet rs;
    
        public void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbConexao?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
           // JOptionPane.showMessageDialog(null, "Conectado com sucesso!");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();

        } catch (SQLException ex) {
           ex.printStackTrace();
        }
    }
        
        public void inserir(String nome){
            connect();
            try {
               
                String insert = "insert into aluno(nome) values (?)";
                ps = conexao.prepareStatement(insert);
                ps.setString(1, nome);
                ps.executeUpdate();
                
            } catch (SQLException ex) {
               ex.printStackTrace();
            }
            
        }
        
}
